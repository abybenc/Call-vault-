# CallVault

Personal Android call recorder for India, built for a Moto G Power 5G.

## What it does
- **Records calls itself** using an Accessibility service (no root). Works on many phones, not all.
- **Upload audio**: any audio file, or share a recording from the Phone app into CallVault.
- **On-phone transcription, like iPhone**: Whisper runs fully offline on the phone right after each call or upload.
  The line being played lights up, and you can tap any line to jump there.
- **Gemini summary (optional, online)**: summary, action items and who-said-what, also good for mixed languages.
- **Contacts + search**: auto-matches the call log, pick a contact, add #tags and notes, search everything said.
- **Saves only on your phone** or SD card (you choose the folder). No cloud backup.

## Install
Download the latest `CallVault.apk` from Releases:
https://github.com/abybenc/callvault/releases/latest/download/CallVault.apk

## Setup on the phone
1. Open CallVault › Settings › **Permissions › Fix**.
2. **Accessibility**: Settings › Accessibility › Downloaded apps › CallVault › On.
   If greyed out: App info › ⋮ › **Allow restricted settings**, then try again.
3. **Battery**: allow background use.
4. **On-phone transcription**: download the Standard model (60 MB, use Wi-Fi).
5. Make a 1 minute test call. If the other side is quiet, change **Audio source** and test again.
6. Optional: paste a Gemini API key (aistudio.google.com/apikey) for summaries.

## Build
GitHub Actions builds the APK on every push to `main` (Android SDK + NDK; whisper.cpp v1.7.6 is fetched by CMake).
Speech models come from huggingface.co/ggerganov/whisper.cpp and are downloaded inside the app.

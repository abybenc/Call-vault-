// Thin JNI bridge between Kotlin (WhisperLib) and whisper.cpp
#include <jni.h>
#include <string.h>
#include <stdint.h>
#include "whisper.h"

static volatile int g_progress = 0;
static volatile int g_abort = 0;

static void on_progress(struct whisper_context *ctx, struct whisper_state *state, int progress, void *user) {
    (void) ctx; (void) state; (void) user;
    g_progress = progress;
}

static bool on_abort(void *user) {
    (void) user;
    return g_abort != 0;
}

JNIEXPORT jlong JNICALL
Java_com_aby_callvault_WhisperLib_initContext(JNIEnv *env, jobject thiz, jstring model_path) {
    (void) thiz;
    const char *path = (*env)->GetStringUTFChars(env, model_path, NULL);
    struct whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = false;
    struct whisper_context *ctx = whisper_init_from_file_with_params(path, cparams);
    (*env)->ReleaseStringUTFChars(env, model_path, path);
    return (jlong) (intptr_t) ctx;
}

JNIEXPORT void JNICALL
Java_com_aby_callvault_WhisperLib_freeContext(JNIEnv *env, jobject thiz, jlong ctx) {
    (void) env; (void) thiz;
    if (ctx != 0) whisper_free((struct whisper_context *) (intptr_t) ctx);
}

JNIEXPORT jint JNICALL
Java_com_aby_callvault_WhisperLib_fullTranscribe(JNIEnv *env, jobject thiz, jlong ctx, jint threads,
                                                 jstring language, jfloatArray audio, jint n_samples) {
    (void) thiz;
    struct whisper_context *c = (struct whisper_context *) (intptr_t) ctx;
    if (c == NULL) return -1;

    const char *lang = (*env)->GetStringUTFChars(env, language, NULL);

    struct whisper_full_params p = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    p.print_realtime = false;
    p.print_progress = false;
    p.print_timestamps = false;
    p.print_special = false;
    p.translate = false;
    p.language = lang;
    p.n_threads = threads;
    p.no_context = true;
    p.single_segment = false;
    p.suppress_blank = true;
    p.progress_callback = on_progress;
    p.progress_callback_user_data = NULL;
    p.abort_callback = on_abort;
    p.abort_callback_user_data = NULL;

    g_progress = 0;
    g_abort = 0;

    jfloat *data = (*env)->GetFloatArrayElements(env, audio, NULL);
    int result = whisper_full(c, p, data, n_samples);
    (*env)->ReleaseFloatArrayElements(env, audio, data, JNI_ABORT);
    (*env)->ReleaseStringUTFChars(env, language, lang);
    return result;
}

JNIEXPORT jint JNICALL
Java_com_aby_callvault_WhisperLib_segmentCount(JNIEnv *env, jobject thiz, jlong ctx) {
    (void) env; (void) thiz;
    return whisper_full_n_segments((struct whisper_context *) (intptr_t) ctx);
}

// Returned as raw bytes: a segment can end in the middle of a UTF-8 character,
// which would crash NewStringUTF. Kotlin decodes it safely.
JNIEXPORT jbyteArray JNICALL
Java_com_aby_callvault_WhisperLib_segmentText(JNIEnv *env, jobject thiz, jlong ctx, jint i) {
    (void) thiz;
    const char *text = whisper_full_get_segment_text((struct whisper_context *) (intptr_t) ctx, i);
    jsize len = text ? (jsize) strlen(text) : 0;
    jbyteArray out = (*env)->NewByteArray(env, len);
    if (len > 0) (*env)->SetByteArrayRegion(env, out, 0, len, (const jbyte *) text);
    return out;
}

// Times are in centiseconds (1/100 s)
JNIEXPORT jlong JNICALL
Java_com_aby_callvault_WhisperLib_segmentT0(JNIEnv *env, jobject thiz, jlong ctx, jint i) {
    (void) env; (void) thiz;
    return whisper_full_get_segment_t0((struct whisper_context *) (intptr_t) ctx, i);
}

JNIEXPORT jlong JNICALL
Java_com_aby_callvault_WhisperLib_segmentT1(JNIEnv *env, jobject thiz, jlong ctx, jint i) {
    (void) env; (void) thiz;
    return whisper_full_get_segment_t1((struct whisper_context *) (intptr_t) ctx, i);
}

JNIEXPORT jint JNICALL
Java_com_aby_callvault_WhisperLib_progress(JNIEnv *env, jobject thiz) {
    (void) env; (void) thiz;
    return g_progress;
}

JNIEXPORT void JNICALL
Java_com_aby_callvault_WhisperLib_abort(JNIEnv *env, jobject thiz) {
    (void) env; (void) thiz;
    g_abort = 1;
}

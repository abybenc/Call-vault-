package com.aby.callvault

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.telephony.TelephonyManager
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

/**
 * Records calls. Running as an Accessibility service is what lets Android allow
 * microphone capture during a call for a normal (non-system) app on many phones.
 * It does not read the screen.
 */
class CallRecordService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var recorder: MediaRecorder? = null
    private var tempFile: File? = null
    private var startedAt = 0L
    private var ringing = false
    private var direction = "unknown"
    private var receiverOn = false

    private val phoneReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                TelephonyManager.EXTRA_STATE_RINGING -> ringing = true
                TelephonyManager.EXTRA_STATE_OFFHOOK ->
                    if (recorder == null && Prefs.autoRecord(this@CallRecordService)) start(if (ringing) "in" else "out")
                TelephonyManager.EXTRA_STATE_IDLE -> {
                    stop()
                    ringing = false
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        ContextCompat.registerReceiver(
            this, phoneReceiver,
            IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED),
            ContextCompat.RECEIVER_EXPORTED
        )
        receiverOn = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        stop()
        if (receiverOn) runCatching { unregisterReceiver(phoneReceiver) }
        running = false
        super.onDestroy()
    }

    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()

    private fun start(dir: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            notifyInfo("Can't record call", "Microphone permission is off. Open CallVault to fix.", null)
            return
        }
        goForeground()
        val folder = File(filesDir, "rec_tmp").apply { mkdirs() }
        val f = File(folder, "call_${System.currentTimeMillis()}.m4a")
        val sources = listOf(
            Prefs.audioSource(this),
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.MIC
        ).distinct()
        for (src in sources) {
            val r = newRecorder()
            try {
                r.setAudioSource(src)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioChannels(1)
                r.setAudioSamplingRate(16000)
                r.setAudioEncodingBitRate(32000) // ~14 MB per hour, small enough for Gemini
                r.setOutputFile(f.absolutePath)
                r.prepare()
                r.start()
                recorder = r
                tempFile = f
                startedAt = System.currentTimeMillis()
                direction = dir
                Log.i(TAG, "Recording with source $src")
                return
            } catch (e: Exception) {
                Log.w(TAG, "Audio source $src failed", e)
                runCatching { r.release() }
                f.delete()
            }
        }
        leaveForeground()
        notifyInfo("Recording failed", "Android blocked the microphone for this call.", null)
    }

    private fun stop() {
        val r = recorder ?: return
        recorder = null
        runCatching { r.stop() }
        runCatching { r.release() }
        leaveForeground()
        val f = tempFile ?: return
        tempFile = null
        val began = startedAt
        val dur = System.currentTimeMillis() - began
        val dir = direction
        if (f.length() < 1024) {
            f.delete()
            return
        }
        val app = applicationContext
        scope.launch {
            delay(2000) // give the call log a moment to update
            val call = CallLogHelper.latestSince(app, began)
            val name = call?.name.orEmpty()
            val number = call?.number.orEmpty()
            val label = name.ifBlank { number.ifBlank { "Unknown" } }
            val fileName = Storage.safeName("${Fmt.fileStamp(began)}_$label") + ".m4a"
            val uri = try {
                f.inputStream().use { input -> Storage.write(app, fileName) { input.copyTo(it) } }
            } catch (e: Exception) {
                Log.e(TAG, "Save failed", e)
                null
            } ?: return@launch
            f.delete()
            val rec = Recording(
                id = UUID.randomUUID().toString(),
                fileUri = uri,
                fileName = fileName,
                timestamp = began,
                durationMs = dur,
                number = number,
                contactName = name,
                direction = if (call != null && call.direction != "unknown") call.direction else dir,
                source = "app",
            )
            Library.upsert(rec)
            val auto = when (Prefs.autoMode(app)) {
                "device" -> Models.isReady(app)
                "gemini" -> Prefs.apiKey(app).isNotBlank()
                else -> false
            }
            notifyInfo("Call saved", "$label · ${Fmt.dur(dur)}" + if (auto) " · transcribing…" else "", rec.id)
            Transcriber.maybeAuto(app, rec.id)
        }
    }

    private fun openIntent(id: String?): PendingIntent {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (id != null) i.putExtra(MainActivity.EXTRA_OPEN, id)
        return PendingIntent.getActivity(
            this, id?.hashCode() ?: 0, i,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun goForeground() {
        val n = NotificationCompat.Builder(this, App.CH_REC)
            .setSmallIcon(R.drawable.ic_stat_rec)
            .setContentTitle("Recording call")
            .setContentText("CallVault is saving this call")
            .setOngoing(true)
            .setContentIntent(openIntent(null))
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_REC, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(NOTIF_REC, n)
        } catch (e: Exception) {
            Log.w(TAG, "Foreground start failed, recording anyway", e)
        }
    }

    private fun leaveForeground() {
        runCatching { stopForeground(Service.STOP_FOREGROUND_REMOVE) }
    }

    @SuppressLint("MissingPermission")
    private fun notifyInfo(title: String, text: String, id: String?) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val n = NotificationCompat.Builder(this, App.CH_INFO)
            .setSmallIcon(R.drawable.ic_stat_rec)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openIntent(id))
            .build()
        NotificationManagerCompat.from(this).notify(id?.hashCode() ?: 7, n)
    }

    companion object {
        private const val TAG = "CallVault"
        private const val NOTIF_REC = 41

        @Volatile
        var running = false
    }
}

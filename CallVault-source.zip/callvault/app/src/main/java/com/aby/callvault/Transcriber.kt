package com.aby.callvault

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Runs transcription in the background, so the transcript is ready right after
 * a call ends (like iPhone), even if you leave the screen.
 *  - "device": Whisper on the phone, offline and private, with timings for tap-to-jump
 *  - "gemini": online, adds speaker labels, summary and action items
 */
object Transcriber {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val active = ConcurrentHashMap.newKeySet<String>()

    private val _progress = MutableStateFlow<Map<String, Int>>(emptyMap())
    /** On-phone progress (0..100) by recording id. */
    val progress: StateFlow<Map<String, Int>> = _progress

    sealed interface Start {
        data object Ok : Start
        data class Blocked(val reason: String) : Start
    }

    /** Called after a call is saved or a file is uploaded. */
    fun maybeAuto(c: Context, id: String) {
        when (Prefs.autoMode(c)) {
            "device" -> if (Models.isReady(c)) startDevice(c, id, notify = true)
            "gemini" -> if (Prefs.apiKey(c).isNotBlank()) startGemini(c, id, notify = true)
        }
    }

    fun startDevice(c: Context, id: String, notify: Boolean = false): Start {
        val app = c.applicationContext
        if (!Models.isReady(app)) return Start.Blocked("Download the on-phone speech model in Settings first.")
        val job = "d:$id"
        if (!active.add(job)) return Start.Ok
        Library.update(id) { it.copy(deviceState = "running", deviceError = "") }
        setProgress(id, 0)
        scope.launch {
            try {
                val rec = Library.get(id) ?: return@launch
                val segs = OnDeviceEngine.transcribe(app, rec) { p -> setProgress(id, p) }
                Library.update(id) { it.copy(segments = segs, deviceState = "done", deviceError = "") }
                if (notify) notifyDone(app, id, "Transcript ready", "tap to read")
            } catch (e: Throwable) {
                Library.update(id) { it.copy(deviceState = "error", deviceError = e.message ?: "On-phone transcription failed") }
            } finally {
                clearProgress(id)
                active.remove(job)
            }
        }
        return Start.Ok
    }

    fun startGemini(c: Context, id: String, notify: Boolean = false): Start {
        val app = c.applicationContext
        val key = Prefs.apiKey(app)
        if (key.isBlank()) return Start.Blocked("Add your Gemini API key in Settings first.")
        val job = "g:$id"
        if (!active.add(job)) return Start.Ok
        Library.update(id) { it.copy(aiState = "running", aiError = "") }
        scope.launch {
            try {
                val rec = Library.get(id) ?: return@launch
                val a = Gemini.analyze(app, rec, key, Prefs.model(app))
                Library.update(id) {
                    it.copy(
                        transcript = a.transcript, summary = a.summary, actionItems = a.actionItems,
                        language = a.language, aiState = "done", aiError = ""
                    )
                }
                if (notify) notifyDone(app, id, "Summary ready", "tap to read")
            } catch (e: Throwable) {
                Library.update(id) { it.copy(aiState = "error", aiError = e.message ?: "Something went wrong") }
            } finally {
                active.remove(job)
            }
        }
        return Start.Ok
    }

    private fun setProgress(id: String, p: Int) {
        _progress.value = _progress.value + (id to p)
    }

    private fun clearProgress(id: String) {
        _progress.value = _progress.value - id
    }

    @SuppressLint("MissingPermission")
    private fun notifyDone(c: Context, id: String, title: String, tail: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val name = Library.get(id)?.displayName ?: "Call"
        val open = PendingIntent.getActivity(
            c, id.hashCode(),
            Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(MainActivity.EXTRA_OPEN, id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, App.CH_INFO)
            .setSmallIcon(R.drawable.ic_stat_rec)
            .setContentTitle(title)
            .setContentText("$name · $tail")
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        NotificationManagerCompat.from(c).notify(id.hashCode(), n)
    }
}

package com.aby.callvault

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

/** Plain voice recorder (meetings, lectures, notes). Keeps going with the screen off. */
class VoiceMemoService : Service() {

    data class State(
        val recording: Boolean = false,
        val paused: Boolean = false,
        val elapsedBefore: Long = 0L,  // time recorded before the last resume
        val resumedAt: Long = 0L,
    ) {
        fun elapsed(now: Long) = elapsedBefore + if (recording && !paused) now - resumedAt else 0L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tempFile: File? = null
    private var startedAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start()
            ACTION_PAUSE -> pause()
            ACTION_RESUME -> resume()
            ACTION_STOP -> stop()
        }
        return START_NOT_STICKY
    }

    private fun notification(paused: Boolean) = NotificationCompat.Builder(this, App.CH_REC)
        .setSmallIcon(R.drawable.ic_stat_rec)
        .setContentTitle(if (paused) "Recording paused" else "Recording voice memo")
        .setContentText("Tap to open CallVault")
        .setOngoing(true)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 11,
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra(MainActivity.EXTRA_RECORDER, true),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        .addAction(0, "Stop & save", PendingIntent.getService(
            this, 12, Intent(this, VoiceMemoService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        ))
        .build()

    private fun start() {
        if (recorder != null) return
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF, notification(false), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(NOTIF, notification(false))
        } catch (e: Exception) {
            Log.e(TAG, "Can't start foreground", e)
            stopSelf()
            return
        }
        val f = File(File(filesDir, "rec_tmp").apply { mkdirs() }, "memo_${System.currentTimeMillis()}.m4a")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(32000)
            r.setAudioEncodingBitRate(48000) // ~21 MB per hour
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
        } catch (e: Exception) {
            Log.e(TAG, "Memo recording failed", e)
            runCatching { r.release() }
            f.delete()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        recorder = r
        tempFile = f
        startedAt = System.currentTimeMillis()
        _state.value = State(recording = true, resumedAt = startedAt)
    }

    private fun pause() {
        val r = recorder ?: return
        val s = _state.value
        if (s.paused) return
        runCatching { r.pause() }
        val now = System.currentTimeMillis()
        _state.value = s.copy(paused = true, elapsedBefore = s.elapsed(now))
        updateNotification(true)
    }

    private fun resume() {
        val r = recorder ?: return
        val s = _state.value
        if (!s.paused) return
        runCatching { r.resume() }
        _state.value = s.copy(paused = false, resumedAt = System.currentTimeMillis())
        updateNotification(false)
    }

    private fun updateNotification(paused: Boolean) {
        runCatching {
            getSystemService(android.app.NotificationManager::class.java).notify(NOTIF, notification(paused))
        }
    }

    private fun stop() {
        val r = recorder
        if (r == null) {
            stopSelf()
            return
        }
        val dur = _state.value.elapsed(System.currentTimeMillis())
        recorder = null
        runCatching { r.stop() }
        runCatching { r.release() }
        _state.value = State()
        stopForeground(STOP_FOREGROUND_REMOVE)
        val f = tempFile
        tempFile = null
        val began = startedAt
        val app = applicationContext
        if (f == null || f.length() < 1024) {
            f?.delete()
            stopSelf()
            return
        }
        scope.launch {
            try {
                val fileName = Storage.safeName("${Fmt.fileStamp(began)}_Voice memo") + ".m4a"
                val uri = f.inputStream().use { input -> Storage.write(app, fileName) { input.copyTo(it) } }
                f.delete()
                val rec = Recording(
                    id = UUID.randomUUID().toString(),
                    fileUri = uri,
                    fileName = fileName,
                    timestamp = began,
                    durationMs = dur,
                    contactName = "Voice memo",
                    direction = "memo",
                    source = "memo",
                )
                Library.upsert(rec)
                _lastSaved.value = rec.id
                Transcriber.maybeAuto(app, rec.id)
            } catch (e: Exception) {
                Log.e(TAG, "Memo save failed", e)
            } finally {
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        recorder?.let { runCatching { it.stop() }; runCatching { it.release() } }
        recorder = null
        if (_state.value.recording) _state.value = State()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "CallVault"
        private const val NOTIF = 52
        const val ACTION_START = "start"
        const val ACTION_PAUSE = "pause"
        const val ACTION_RESUME = "resume"
        const val ACTION_STOP = "stop"

        @Volatile
        private var recorder: MediaRecorder? = null

        private val _state = MutableStateFlow(State())
        val state: StateFlow<State> = _state

        private val _lastSaved = MutableStateFlow<String?>(null)
        val lastSaved: StateFlow<String?> = _lastSaved
        fun consumeSaved() {
            _lastSaved.value = null
        }

        /** Loudness 0..32767 for the level meter. */
        fun amplitude(): Int = runCatching { recorder?.maxAmplitude ?: 0 }.getOrDefault(0)
    }
}

package com.aby.callvault

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.OutputStream
import java.util.UUID
import kotlin.math.abs

/**
 * Where recordings live. Default: the phone's public "Recordings/CallVault" folder, so the files
 * show up in the Files app and stay even if CallVault is uninstalled. Or any folder you pick (phone or SD card).
 */
object Storage {
    private const val TAG = "CallVault"

    private fun appDir(c: Context): File =
        (c.getExternalFilesDir("Recordings") ?: File(c.filesDir, "Recordings")).apply { mkdirs() }

    fun safeName(s: String): String =
        s.replace(Regex("[^\\p{L}\\p{N}+_. -]"), "_").replace(Regex("_+"), "_").take(90)

    /** Writes a new file and returns its Uri string. */
    fun write(c: Context, name: String, writer: (OutputStream) -> Unit): String {
        val folder = Prefs.folderUri(c)
        if (folder != null) {
            try {
                val tree = DocumentFile.fromTreeUri(c, Uri.parse(folder))
                // octet-stream keeps our ".m4a" name exactly as given
                val doc = tree?.createFile("application/octet-stream", name)
                if (doc != null) {
                    c.contentResolver.openOutputStream(doc.uri)!!.use { writer(it) }
                    return doc.uri.toString()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Chosen folder failed, using app folder", e)
            }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return writeToPhoneRecordings(c, name, writer)
            } catch (e: Exception) {
                Log.w(TAG, "Recordings folder failed, using app folder", e)
            }
        }
        var f = File(appDir(c), name)
        var n = 1
        while (f.exists()) {
            f = File(appDir(c), name.substringBeforeLast('.') + "_" + n++ + "." + name.substringAfterLast('.', "m4a"))
        }
        f.outputStream().use { writer(it) }
        return Uri.fromFile(f).toString()
    }

    private val publicDir: String
        get() = if (Build.VERSION.SDK_INT >= 31) Environment.DIRECTORY_RECORDINGS + "/CallVault"
        else Environment.DIRECTORY_MUSIC + "/CallVault"

    /** Saves into Phone storage › Recordings › CallVault (no extra permission needed on Android 10+). */
    private fun writeToPhoneRecordings(c: Context, name: String, writer: (OutputStream) -> Unit): String {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, publicDir)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = c.contentResolver.insert(collection, values) ?: throw java.io.IOException("Could not create file")
        try {
            c.contentResolver.openOutputStream(uri)!!.use { writer(it) }
            c.contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            runCatching { c.contentResolver.delete(uri, null, null) }
            throw e
        }
        return uri.toString()
    }

    fun delete(c: Context, uriStr: String) {
        val u = Uri.parse(uriStr)
        try {
            if (u.scheme == "file") File(u.path!!).delete()
            else if (u.authority == MediaStore.AUTHORITY) c.contentResolver.delete(u, null, null)
            else DocumentsContract.deleteDocument(c.contentResolver, u)
        } catch (e: Exception) {
            Log.w(TAG, "Delete failed", e)
        }
    }

    /** A Uri other apps (WhatsApp, Gmail…) can read. */
    fun shareUri(c: Context, uriStr: String): Uri {
        val u = Uri.parse(uriStr)
        return if (u.scheme == "file") FileProvider.getUriForFile(c, "${c.packageName}.files", File(u.path!!)) else u
    }

    fun folderLabel(c: Context): String {
        val folder = Prefs.folderUri(c) ?: return if (Build.VERSION.SDK_INT >= 29) "Phone storage › $publicDir"
        else "Phone storage › Android/data/com.aby.callvault/files/Recordings"
        return try {
            val doc = DocumentFile.fromTreeUri(c, Uri.parse(folder))
            val id = DocumentsContract.getTreeDocumentId(Uri.parse(folder)) // e.g. primary:Recordings or 1A2B-3C4D:Calls
            val where = if (id.startsWith("primary")) "Phone storage" else "SD card"
            "$where › ${id.substringAfter(':').ifBlank { doc?.name ?: "" }}"
        } catch (e: Exception) {
            folder
        }
    }

    fun durationOf(c: Context, uri: Uri): Long = try {
        MediaMetadataRetriever().run {
            setDataSource(c, uri)
            val d = extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            release()
            d
        }
    } catch (e: Exception) {
        0L
    }
}

data class CallInfo(val number: String, val name: String, val direction: String, val date: Long)

object CallLogHelper {
    private fun has(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    /** Most recent call that started after [since] (minus a little slack for ringing time). */
    fun latestSince(c: Context, since: Long): CallInfo? =
        query(c, since - 3 * 60_000, Long.MAX_VALUE).maxByOrNull { it.date }

    /** Call whose start time is closest to [start]. Used to match imported files. */
    fun matchAround(c: Context, start: Long): CallInfo? =
        query(c, start - 5 * 60_000, start + 5 * 60_000).minByOrNull { abs(it.date - start) }

    private fun query(c: Context, from: Long, to: Long): List<CallInfo> {
        if (!has(c, Manifest.permission.READ_CALL_LOG)) return emptyList()
        val out = mutableListOf<CallInfo>()
        try {
            c.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                "${CallLog.Calls.DATE} >= ? AND ${CallLog.Calls.DATE} <= ?",
                arrayOf(from.toString(), to.toString()),
                "${CallLog.Calls.DATE} DESC"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val number = cur.getString(0) ?: ""
                    val dir = when (cur.getInt(2)) {
                        CallLog.Calls.INCOMING_TYPE -> "in"
                        CallLog.Calls.OUTGOING_TYPE -> "out"
                        CallLog.Calls.MISSED_TYPE -> "missed"
                        else -> "unknown"
                    }
                    val name = cur.getString(1)?.takeIf { it.isNotBlank() } ?: lookupName(c, number)
                    out += CallInfo(number, name, dir, cur.getLong(3))
                }
            }
        } catch (e: Exception) {
            Log.w("CallVault", "Call log read failed", e)
        }
        return out
    }

    fun lookupName(c: Context, number: String): String {
        if (number.isBlank() || !has(c, Manifest.permission.READ_CONTACTS)) return ""
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            c.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) ?: "" else "" } ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    /** Reads name + number from a contact picked with ACTION_PICK on the Phone table. */
    fun readPicked(c: Context, uri: Uri): Pair<String, String>? = try {
        c.contentResolver.query(
            uri,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { if (it.moveToFirst()) (it.getString(0) ?: "") to (it.getString(1) ?: "") else null }
    } catch (e: Exception) {
        null
    }
}

/** Brings in recordings shared from the Phone app or picked from files. */
object Importer {
    fun import(c: Context, uri: Uri): Recording? {
        var display = "recording.m4a"
        var modified = 0L
        try {
            c.contentResolver.query(uri, null, null, null, null)?.use { cur ->
                if (cur.moveToFirst()) {
                    val ni = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0) cur.getString(ni)?.let { display = it }
                    val mi = cur.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                    if (mi >= 0) modified = cur.getLong(mi)
                }
            }
        } catch (_: Exception) {
        }
        val dur = Storage.durationOf(c, uri)
        val end = if (modified > 0) modified else System.currentTimeMillis()
        val start = end - dur
        val match = if (modified > 0) CallLogHelper.matchAround(c, start) else null

        val ext = display.substringAfterLast('.', "m4a").lowercase().take(5)
        val label = match?.name?.ifBlank { match.number } ?: guessName(display)
        val outName = Storage.safeName("${Fmt.fileStamp(match?.date ?: start)}_$label") + "." + ext

        val stored = c.contentResolver.openInputStream(uri)?.use { input ->
            Storage.write(c, outName) { input.copyTo(it) }
        } ?: return null

        val rec = Recording(
            id = UUID.randomUUID().toString(),
            fileUri = stored,
            fileName = outName,
            timestamp = match?.date ?: start,
            durationMs = dur,
            number = match?.number ?: "",
            contactName = match?.name ?: guessName(display),
            direction = match?.direction ?: "unknown",
            source = "import",
        )
        Library.upsert(rec)
        Transcriber.maybeAuto(c, rec.id)
        return rec
    }

    private fun guessName(file: String): String = file.substringBeforeLast('.')
        .replace('_', ' ')
        .replace(Regex("\\d{6,}"), " ")
        .replace(Regex("(?i)call ?recording|recording|call"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}

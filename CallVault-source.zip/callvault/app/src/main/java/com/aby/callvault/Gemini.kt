package com.aby.callvault

import android.content.Context
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Analysis(val transcript: String, val summary: String, val actionItems: List<String>, val language: String)

class GeminiException(val code: Int, msg: String) : IOException(msg)

/** Sends the audio to Gemini and gets back a transcript, summary and action items. */
object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com"
    private const val INLINE_LIMIT = 14 * 1024 * 1024

    suspend fun analyze(c: Context, r: Recording, key: String, model: String): Analysis = withContext(Dispatchers.IO) {
        val bytes = c.contentResolver.openInputStream(Uri.parse(r.fileUri))?.use { it.readBytes() }
            ?: throw IOException("Can't read the audio file. Was it moved or deleted?")
        val mime = mimeFor(r.fileName)
        try {
            run(bytes, mime, r, key, model)
        } catch (e: GeminiException) {
            // Some m4a files are only accepted when labelled as AAC
            if (e.code == 400 && mime == "audio/mp4") run(bytes, "audio/aac", r, key, model) else throw e
        }
    }

    private fun run(bytes: ByteArray, mime: String, r: Recording, key: String, model: String): Analysis {
        val audio = if (bytes.size <= INLINE_LIMIT) {
            JSONObject().put("inline_data", JSONObject()
                .put("mime_type", mime)
                .put("data", Base64.encodeToString(bytes, Base64.NO_WRAP)))
        } else {
            JSONObject().put("file_data", JSONObject()
                .put("mime_type", mime)
                .put("file_uri", upload(bytes, mime, key)))
        }
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                .put(JSONObject().put("text", prompt(r)))
                .put(audio))))
            .put("generationConfig", JSONObject()
                .put("responseMimeType", "application/json")
                .put("temperature", 0.2))
        val resp = post("$BASE/v1beta/models/${model.trim()}:generateContent", key, body.toString())
        return parse(resp)
    }

    private fun prompt(r: Recording): String {
        val other = r.contactName.ifBlank { "Caller" }
        return """
            This is a phone call recording from India. People may speak English, Malayalam, Hindi, Tamil or a mix.
            The phone owner is "Me". The other person is "$other".
            Return ONLY a JSON object with these keys:
            "transcript": string. The full conversation, one line per turn as "Name: words". Keep the original language.
                For any line not in English, add the English meaning in square brackets after it.
            "summary": string. 3 to 6 short lines in simple English, each starting with "• ".
            "action_items": array of strings. Promises, dates, amounts, numbers to remember and follow-ups. Empty array if none.
            "language": string. The main language(s) used.
            If the audio is silent, or only one side of the call can be heard, say that clearly in the summary.
        """.trimIndent()
    }

    private fun mimeFor(name: String): String = when (name.substringAfterLast('.').lowercase()) {
        "mp3" -> "audio/mp3"
        "wav" -> "audio/wav"
        "ogg", "opus" -> "audio/ogg"
        "flac" -> "audio/flac"
        "aac" -> "audio/aac"
        "amr" -> "audio/amr"
        else -> "audio/mp4"
    }

    private fun post(url: String, key: String, json: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 30_000
            readTimeout = 300_000
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        conn.outputStream.use { it.write(json.toByteArray()) }
        return readResponse(conn)
    }

    private fun readResponse(conn: HttpURLConnection): String {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
                .getOrDefault(text.take(300))
            throw GeminiException(code, "Gemini error $code: $msg")
        }
        return text
    }

    /** Big files (long calls) go through the Gemini Files API. */
    private fun upload(bytes: ByteArray, mime: String, key: String): String {
        val start = (URL("$BASE/upload/v1beta/files").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 30_000
            readTimeout = 60_000
            setRequestProperty("x-goog-api-key", key)
            setRequestProperty("X-Goog-Upload-Protocol", "resumable")
            setRequestProperty("X-Goog-Upload-Command", "start")
            setRequestProperty("X-Goog-Upload-Header-Content-Length", bytes.size.toString())
            setRequestProperty("X-Goog-Upload-Header-Content-Type", mime)
            setRequestProperty("Content-Type", "application/json")
        }
        start.outputStream.use {
            it.write(JSONObject().put("file", JSONObject().put("display_name", "call")).toString().toByteArray())
        }
        readResponse(start)
        val uploadUrl = start.getHeaderField("x-goog-upload-url") ?: throw IOException("Gemini upload did not start")

        val up = (URL(uploadUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 30_000
            readTimeout = 300_000
            setFixedLengthStreamingMode(bytes.size)
            setRequestProperty("X-Goog-Upload-Offset", "0")
            setRequestProperty("X-Goog-Upload-Command", "upload, finalize")
        }
        up.outputStream.use { it.write(bytes) }
        val file = JSONObject(readResponse(up)).getJSONObject("file")
        val name = file.getString("name")
        val uri = file.getString("uri")
        var state = file.optString("state")
        var tries = 0
        while (state == "PROCESSING" && tries++ < 60) {
            Thread.sleep(2000)
            val check = (URL("$BASE/v1beta/$name").openConnection() as HttpURLConnection).apply {
                setRequestProperty("x-goog-api-key", key)
            }
            state = JSONObject(readResponse(check)).optString("state")
        }
        if (state == "FAILED") throw IOException("Gemini could not process this audio")
        return uri
    }

    private fun parse(resp: String): Analysis {
        val root = JSONObject(resp)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            throw IOException("Gemini gave no answer. " + (root.optJSONObject("promptFeedback")?.toString() ?: ""))
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw IOException("Gemini gave an empty answer")
        val text = buildString {
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought")) append(p.optString("text"))
            }
        }.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val o = JSONObject(text)
        val summary = when (val s = o.opt("summary")) {
            is JSONArray -> s.toStringList().joinToString("\n") { "• $it" }
            else -> o.optString("summary")
        }
        return Analysis(
            transcript = o.optString("transcript"),
            summary = summary,
            actionItems = o.optJSONArray("action_items").toStringList(),
            language = o.optString("language"),
        )
    }
}

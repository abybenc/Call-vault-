@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.aby.callvault

import android.Manifest
import android.content.Context
import android.os.Build
import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ───────────────────────── Home ─────────────────────────

@Composable
fun HomeScreen(tick: Int, onOpen: (String) -> Unit, onSettings: () -> Unit, onRecord: () -> Unit) {
    val ctx = LocalContext.current
    val items by Library.items.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var person by rememberSaveable { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val ready = remember(tick) { Setup.isReady(ctx) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            val n = withContext(Dispatchers.IO) {
                uris.count { runCatching { Importer.import(ctx, it) }.getOrNull() != null }
            }
            Toast.makeText(ctx, "Imported $n recording(s)", Toast.LENGTH_SHORT).show()
        }
    }

    val filtered = remember(items, query, person) {
        items.filter { (person == null || it.personKey == person) && it.matches(query) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("CallVault", fontWeight = FontWeight.SemiBold) },
                actions = {
                    IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "Settings") }
                }
            )
        },
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SmallFloatingActionButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                    Icon(Icons.Default.UploadFile, contentDescription = "Upload audio")
                }
                ExtendedFloatingActionButton(
                    onClick = onRecord,
                    icon = { Icon(Icons.Default.Mic, contentDescription = null) },
                    text = { Text("Record") },
                    containerColor = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer,
                )
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            val memo by VoiceMemoService.state.collectAsState()
            if (memo.recording) Card(
                onClick = onRecord,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FiberManualRecord, contentDescription = null, tint = Color(0xFFD32F2F))
                    Spacer(Modifier.width(8.dp))
                    Text(if (memo.paused) "Voice memo paused · tap to open" else "Recording voice memo · tap to open")
                }
            }
            if (!ready) SetupBanner(onSettings)
            else if (remember(tick) { Prefs.autoRecord(ctx) }) Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    "Auto-record is on. Every call is recorded and saved to your phone.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search name, number, tag or words said") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear")
                    }
                },
                singleLine = true,
            )
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Recordings (${items.size})") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("People") })
            }
            if (tab == 0) {
                person?.let { p ->
                    InputChip(
                        selected = true,
                        onClick = { person = null },
                        label = { Text("Only: $p") },
                        trailingIcon = { Icon(Icons.Default.Close, contentDescription = "Clear filter", Modifier.size(16.dp)) },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
                if (filtered.isEmpty()) EmptyState(items.isEmpty())
                else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
                    items(filtered, key = { it.id }) { r -> RecordingRow(r) { onOpen(r.id) } }
                }
            } else {
                PeopleList(items.filter { it.matches(query) }) {
                    person = it
                    tab = 0
                }
            }
        }
    }
}

@Composable
private fun SetupBanner(onSettings: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Warning, contentDescription = null)
            Spacer(Modifier.width(12.dp))
            Text("Finish setup so calls start recording", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = onSettings) { Text("Set up") }
        }
    }
}

@Composable
private fun EmptyState(nothingYet: Boolean) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Mic, contentDescription = null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp))
        Text(
            if (nothingYet) "No recordings yet.\nMake a call, or share a recording from the Phone app to CallVault."
            else "Nothing matches your search.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
private fun Avatar(name: String) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "?",
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun RecordingRow(r: Recording, onClick: () -> Unit) {
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        leadingContent = { Avatar(r.displayName) },
        headlineContent = { Text(r.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = {
            Column {
                Text(
                    "${Fmt.direction(r.direction)} · ${Fmt.date(r.timestamp)} · ${Fmt.dur(r.durationMs)}",
                    style = MaterialTheme.typography.bodySmall
                )
                val extra = buildString {
                    when {
                        r.deviceState == "running" || r.aiState == "running" -> append("⏳ Transcribing…  ")
                        r.summary.isNotBlank() -> append("✨ Summary  ")
                        r.segments.isNotEmpty() || r.transcript.isNotBlank() -> append("📝 Transcript  ")
                        r.deviceState == "error" || r.aiState == "error" -> append("⚠ Transcript failed  ")
                    }
                    append(r.tags.joinToString(" ") { "#$it" })
                }
                if (extra.isNotBlank()) Text(
                    extra, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    )
    HorizontalDivider()
}

@Composable
private fun PeopleList(items: List<Recording>, onPick: (String) -> Unit) {
    val groups = remember(items) {
        items.groupBy { it.personKey }.toList().sortedByDescending { (_, list) -> list.maxOf { it.timestamp } }
    }
    if (groups.isEmpty()) {
        EmptyState(true)
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(groups, key = { it.first }) { (name, list) ->
            ListItem(
                modifier = Modifier.clickable { onPick(name) },
                leadingContent = { Avatar(name) },
                headlineContent = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = {
                    Text(
                        "${list.size} call${if (list.size == 1) "" else "s"} · last ${Fmt.date(list.maxOf { it.timestamp })}",
                        style = MaterialTheme.typography.bodySmall
                    )
                },
                trailingContent = { Text(Fmt.dur(list.sumOf { it.durationMs }), style = MaterialTheme.typography.labelSmall) }
            )
            HorizontalDivider()
        }
    }
}

// ───────────────────────── Detail ─────────────────────────

@Composable
fun DetailScreen(id: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val items by Library.items.collectAsState()
    val r = items.firstOrNull { it.id == id }
    if (r == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val clipboard = LocalClipboardManager.current
    var deviceNotice by remember { mutableStateOf<String?>(null) }
    var aiNotice by remember { mutableStateOf<String?>(null) }
    var showSpeakers by rememberSaveable { mutableStateOf(false) }
    val progress by Transcriber.progress.collectAsState()
    val player = rememberPlayerState(r.fileUri)
    var confirmDelete by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(false) }

    val contactPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        res.data?.data?.let { uri ->
            CallLogHelper.readPicked(ctx, uri)?.let { (name, num) ->
                Library.update(id) { it.copy(contactName = name, number = num.ifBlank { it.number }) }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(r.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                },
                actions = {
                    IconButton(onClick = { share(ctx, r) }) { Icon(Icons.Default.Share, contentDescription = "Share") }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column {
                Text("${Fmt.direction(r.direction)} · ${Fmt.date(r.timestamp)}", style = MaterialTheme.typography.bodyMedium)
                if (r.number.isNotBlank() && r.number != r.displayName) {
                    Text(r.number, style = MaterialTheme.typography.bodySmall)
                }
                if (r.source == "import") Text("Imported file", style = MaterialTheme.typography.labelSmall)
            }

            PlayerCard(player)

            SectionCard("Transcript") {
                val running = r.deviceState == "running"
                if (running) {
                    val p = progress[id] ?: 0
                    LinearProgressIndicator(progress = { p / 100f }, modifier = Modifier.fillMaxWidth())
                    Text(
                        "Transcribing on your phone… $p%. Works offline, and you can leave this screen.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (r.segments.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Tap a line to play from there",
                            style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(r.segments.joinToString("\n") { "[${Fmt.dur(it.startMs)}] ${it.text}" }))
                            Toast.makeText(ctx, "Transcript copied", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Copy")
                        }
                    }
                    SyncedTranscript(r.segments, player)
                } else if (!running && r.deviceState != "error") {
                    Text("No transcript yet.", style = MaterialTheme.typography.bodySmall)
                }
                if (r.deviceState == "error" && r.deviceError.isNotBlank()) {
                    Text(r.deviceError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                deviceNotice?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                if (!running) {
                    val onClick = {
                        deviceNotice = (Transcriber.startDevice(ctx, id) as? Transcriber.Start.Blocked)?.reason
                    }
                    if (r.segments.isEmpty()) Button(onClick = onClick) {
                        Icon(Icons.Default.PhoneAndroid, contentDescription = null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Transcribe on phone")
                    } else OutlinedButton(onClick = onClick) { Text("Redo on phone") }
                }
            }

            SectionCard("Summary · Gemini (online)") {
                val running = r.aiState == "running"
                if (running) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text("Sending audio to Gemini… long calls can take a minute.", style = MaterialTheme.typography.bodySmall)
                }
                if (r.aiState == "error" && r.aiError.isNotBlank()) {
                    Text(r.aiError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                aiNotice?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                if (r.summary.isNotBlank()) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            SelectionContainer { Text(r.summary, style = MaterialTheme.typography.bodyMedium) }
                            if (r.actionItems.isNotEmpty()) {
                                Spacer(Modifier.height(4.dp))
                                Text("Action items", style = MaterialTheme.typography.titleSmall)
                                r.actionItems.forEach { Text("☐ $it", style = MaterialTheme.typography.bodyMedium) }
                            }
                        }
                    }
                }
                if (r.transcript.isNotBlank()) {
                    TextButton(onClick = { showSpeakers = !showSpeakers }) {
                        Text(if (showSpeakers) "Hide who-said-what" else "Show who-said-what")
                    }
                    if (showSpeakers) TranscriptBubbles(r.transcript)
                }
                if (!running) {
                    val onClick = {
                        aiNotice = (Transcriber.startGemini(ctx, id) as? Transcriber.Start.Blocked)?.reason
                    }
                    if (r.summary.isBlank()) Button(onClick = onClick) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Summarize with Gemini")
                    } else OutlinedButton(onClick = onClick) { Text("Run again") }
                    Text(
                        "Adds a summary, action items and who said what. The audio is sent to Google for this one request.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            SectionCard("Contact") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        contactPicker.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
                    }) {
                        Icon(Icons.Default.Person, contentDescription = null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Pick contact")
                    }
                    OutlinedButton(onClick = { editName = true }) {
                        Icon(Icons.Default.Edit, contentDescription = null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Type name")
                    }
                }
            }

            TagEditor(r.tags) { newTags -> Library.update(id) { it.copy(tags = newTags) } }

            NotesField(r)

            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete recording?") },
            text = { Text("The audio file and its transcript will be removed from your phone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    Library.delete(ctx, id)
                    onBack()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }

    if (editName) {
        var name by remember { mutableStateOf(r.contactName) }
        AlertDialog(
            onDismissRequest = { editName = false },
            title = { Text("Who was this call with?") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") }) },
            confirmButton = {
                TextButton(onClick = {
                    Library.update(id) { it.copy(contactName = name.trim()) }
                    editName = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editName = false }) { Text("Cancel") } }
        )
    }
}

private fun share(ctx: Context, r: Recording) {
    try {
        val uri = Storage.shareUri(ctx, r.fileUri)
        val i = Intent(Intent.ACTION_SEND)
            .setType("audio/*")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share recording"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Can't share: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

/** Playback state shared by the player and the tap-to-jump transcript. */
class PlayerState(val player: MediaPlayer) {
    var prepared by mutableStateOf(false)
    var playing by mutableStateOf(false)
    var pos by mutableIntStateOf(0)
    var total by mutableIntStateOf(0)
    var speed by mutableFloatStateOf(1f)
    var err by mutableStateOf<String?>(null)

    fun toggle() {
        if (!prepared) return
        if (playing) {
            player.pause()
            playing = false
        } else {
            player.start()
            playing = true
        }
    }

    fun seek(ms: Int) {
        pos = ms
        if (prepared) player.seekTo(ms)
    }

    fun playFrom(ms: Long) {
        seek(ms.toInt())
        if (prepared && !playing) {
            player.start()
            playing = true
        }
    }

    fun setRate(s: Float) {
        speed = s
        if (prepared) runCatching {
            player.playbackParams = player.playbackParams.setSpeed(s)
            if (!playing) player.pause()
        }
    }
}

@Composable
fun rememberPlayerState(uri: String): PlayerState {
    val ctx = LocalContext.current
    val st = remember(uri) { PlayerState(MediaPlayer()) }
    DisposableEffect(uri) {
        try {
            st.player.setDataSource(ctx, Uri.parse(uri))
            st.player.setOnPreparedListener {
                st.prepared = true
                st.total = it.duration
            }
            st.player.setOnCompletionListener {
                st.playing = false
                st.pos = 0
            }
            st.player.prepareAsync()
        } catch (e: Exception) {
            st.err = "Can't open this file. It may have been moved or deleted."
        }
        onDispose { runCatching { st.player.release() } }
    }
    LaunchedEffect(st.playing) {
        while (st.playing) {
            st.pos = runCatching { st.player.currentPosition }.getOrDefault(st.pos)
            delay(200)
        }
    }
    return st
}

@Composable
private fun PlayerCard(st: PlayerState) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            st.err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledIconButton(enabled = st.prepared, onClick = { st.toggle() }) {
                    Icon(
                        if (st.playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (st.playing) "Pause" else "Play"
                    )
                }
                Slider(
                    value = if (st.total > 0) st.pos.toFloat() / st.total else 0f,
                    onValueChange = { f -> st.seek((f * st.total).toInt()) },
                    enabled = st.prepared,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Text("${Fmt.dur(st.pos.toLong())} / ${Fmt.dur(st.total.toLong())}", style = MaterialTheme.typography.labelSmall)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf(1f, 1.5f, 2f).forEach { s ->
                    FilterChip(
                        selected = st.speed == s,
                        onClick = { st.setRate(s) },
                        label = { Text(if (s == 1f) "1x" else "${s}x") }
                    )
                }
            }
        }
    }
}

/** Like iPhone: the line being played lights up, tap any line to jump there. */
@Composable
private fun SyncedTranscript(segs: List<Segment>, st: PlayerState) {
    val current = if (st.playing || st.pos > 0) segs.indexOfLast { it.startMs <= st.pos } else -1
    run {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            segs.forEachIndexed { i, s ->
                val on = i == current
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.small)
                        .background(if (on) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                        .clickable { st.playFrom(s.startMs) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        Fmt.dur(s.startMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.width(48.dp).padding(top = 2.dp)
                    )
                    Text(
                        s.text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (on) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (on) FontWeight.Medium else FontWeight.Normal
                    )
                }
            }
        }
    }
}

private data class Turn(val speaker: String, val text: String)

private fun parseTurns(transcript: String): List<Turn> {
    val turns = mutableListOf<Turn>()
    val speakerLine = Regex("^\\s*([^:\\[\\]]{1,30}):\\s*(.*)$")
    transcript.lines().map { it.trim() }.filter { it.isNotEmpty() }.forEach { line ->
        val m = speakerLine.find(line)
        if (m != null) turns += Turn(m.groupValues[1].trim(), m.groupValues[2])
        else if (turns.isNotEmpty()) turns[turns.lastIndex] = turns.last().let { it.copy(text = it.text + "\n" + line) }
        else turns += Turn("", line)
    }
    return turns
}

/** iPhone-style transcript: your lines on the right, the other person on the left. */
@Composable
private fun TranscriptBubbles(transcript: String) {
    val turns = remember(transcript) { parseTurns(transcript) }
    SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            turns.forEach { t ->
                val mine = t.speaker.equals("me", ignoreCase = true)
                Column(
                    Modifier.fillMaxWidth(),
                    horizontalAlignment = if (mine) Alignment.End else Alignment.Start
                ) {
                    if (t.speaker.isNotBlank()) Text(
                        t.speaker, style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    Box(
                        Modifier
                            .fillMaxWidth(0.85f)
                            .wrapContentWidth(if (mine) Alignment.End else Alignment.Start)
                            .clip(MaterialTheme.shapes.large)
                            .background(
                                if (mine) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            t.text, style = MaterialTheme.typography.bodyMedium,
                            color = if (mine) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TagEditor(tags: List<String>, onChange: (List<String>) -> Unit) {
    var text by remember { mutableStateOf("") }
    fun add(t: String) {
        val clean = t.trim().removePrefix("#").lowercase()
        if (clean.isNotEmpty() && clean !in tags) onChange(tags + clean)
        text = ""
    }
    SectionCard("Tags") {
        if (tags.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            tags.forEach { t ->
                InputChip(
                    selected = false,
                    onClick = { onChange(tags - t) },
                    label = { Text("#$t") },
                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = "Remove", Modifier.size(16.dp)) }
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Add a tag") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { add(text) })
            )
            IconButton(onClick = { add(text) }) { Icon(Icons.Default.Add, contentDescription = "Add tag") }
        }
        val suggestions = listOf("work", "family", "bank", "important", "follow-up").filter { it !in tags }
        if (suggestions.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            suggestions.forEach { s -> SuggestionChip(onClick = { add(s) }, label = { Text("+ $s") }) }
        }
    }
}

@Composable
private fun NotesField(r: Recording) {
    var notes by remember(r.id) { mutableStateOf(r.notes) }
    LaunchedEffect(notes) {
        delay(700)
        if (notes != Library.get(r.id)?.notes) Library.update(r.id) { it.copy(notes = notes) }
    }
    OutlinedTextField(
        value = notes,
        onValueChange = { notes = it },
        label = { Text("My notes") },
        modifier = Modifier.fillMaxWidth(),
        minLines = 3
    )
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

// ───────────────────────── Settings ─────────────────────────

@Composable
fun SettingsScreen(tick: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val key = tick + refresh
    val permsOk = remember(key) { Setup.permissionsGranted(ctx) }
    val a11yOk = remember(key) { Setup.accessibilityEnabled(ctx) }
    val batteryOk = remember(key) { Setup.batteryUnrestricted(ctx) }
    val folderLabel = remember(key) { Storage.folderLabel(ctx) }
    val hasFolder = remember(key) { Prefs.folderUri(ctx) != null }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            Prefs.setFolder(ctx, uri.toString())
            refresh++
        }
    }

    var auto by remember { mutableStateOf(Prefs.autoRecord(ctx)) }
    var source by remember { mutableIntStateOf(Prefs.audioSource(ctx)) }
    var apiKey by remember { mutableStateOf(Prefs.apiKey(ctx)) }
    var model by remember { mutableStateOf(Prefs.model(ctx)) }
    var showKey by remember { mutableStateOf(false) }
    var autoMode by remember { mutableStateOf(Prefs.autoMode(ctx)) }
    var modelId by remember { mutableStateOf(Prefs.modelId(ctx)) }
    val dl by Models.downloading.collectAsState()
    val modelReady = remember(key, dl) { Models.all.associate { it.id to Models.isReady(ctx, it) } }
    var dlError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard("Setup checklist") {
                StepRow("1. Permissions", "Microphone, phone, call log, contacts, notifications", permsOk) {
                    permLauncher.launch(Setup.permissions())
                }
                StepRow(
                    "2. Turn on CallVault in Accessibility",
                    "Accessibility › Downloaded apps › CallVault › On. If it is greyed out: open App info, tap ⋮ (top right) › Allow restricted settings, then try again.",
                    a11yOk
                ) { open(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                TextButton(onClick = {
                    open(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                }) { Text("Open App info") }
                StepRow("3. Allow background use", "Stops Android from stopping the recorder during calls", batteryOk) {
                    open(ctx, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
                }
            }

            SectionCard("Recording") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Record every call automatically", style = MaterialTheme.typography.bodyLarge)
                        Text("Incoming and outgoing", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = auto, onCheckedChange = {
                        auto = it
                        Prefs.setAutoRecord(ctx, it)
                    })
                }
                HorizontalDivider()
                Text("Audio source", style = MaterialTheme.typography.titleSmall)
                listOf(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION to "Voice recognition (try first)",
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION to "Voice communication",
                    MediaRecorder.AudioSource.MIC to "Microphone (best with speakerphone)",
                    MediaRecorder.AudioSource.VOICE_CALL to "Voice call (both sides, works only on some phones)",
                ).forEach { (value, label) ->
                    Row(
                        Modifier.fillMaxWidth().selectable(selected = source == value, onClick = {
                            source = value
                            Prefs.setAudioSource(ctx, value)
                        }),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = source == value, onClick = null)
                        Spacer(Modifier.width(8.dp))
                        Text(label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Text(
                    "Make a 1 minute test call after setup. If the other person is too soft, switch the source and test again. If one doesn't work, CallVault falls back to the next one automatically.",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            SectionCard("Save location") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Folder, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(folderLabel, style = MaterialTheme.typography.bodyMedium)
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { folderLauncher.launch(null) }) { Text("Choose folder (phone or SD card)") }
                    if (hasFolder) OutlinedButton(onClick = {
                        Prefs.setFolder(ctx, null)
                        refresh++
                    }) { Text("Use Recordings folder") }
                }
                Text(
                    "Every recording is saved here automatically. Open the Files app › Recordings › CallVault to see them. They stay even if you uninstall CallVault. Pick a different folder (or your SD card) any time; old recordings stay where they are.",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            SectionCard("On-phone transcription (offline)") {
                Text(
                    "Like iPhone: the speech model runs on your phone, so nothing leaves it. Download one model once (use Wi-Fi).",
                    style = MaterialTheme.typography.bodySmall
                )
                Models.all.forEach { m ->
                    val isSel = modelId == m.id
                    val ready = modelReady[m.id] == true
                    val dlPct = dl?.takeIf { it.first == m.id }?.second
                    Row(
                        Modifier.fillMaxWidth().selectable(selected = isSel, onClick = {
                            modelId = m.id
                            Prefs.setModelId(ctx, m.id)
                        }),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = isSel, onClick = null)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${m.label} · ${m.sizeMb} MB", style = MaterialTheme.typography.bodyMedium)
                            Text(m.note, style = MaterialTheme.typography.bodySmall)
                        }
                        when {
                            dlPct != null -> Text("$dlPct%", style = MaterialTheme.typography.labelMedium)
                            ready -> TextButton(onClick = {
                                Models.delete(ctx, m)
                                refresh++
                            }) { Text("Remove") }
                            else -> TextButton(enabled = dl == null, onClick = {
                                dlError = null
                                modelId = m.id
                                Prefs.setModelId(ctx, m.id)
                                scope.launch {
                                    try {
                                        Models.download(ctx, m)
                                    } catch (e: Exception) {
                                        dlError = "Download failed: ${e.message}"
                                    }
                                    refresh++
                                }
                            }) { Text("Download") }
                        }
                    }
                    if (dlPct != null) LinearProgressIndicator(progress = { dlPct / 100f }, modifier = Modifier.fillMaxWidth())
                }
                dlError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                HorizontalDivider()
                Text("Right after each call or upload", style = MaterialTheme.typography.titleSmall)
                listOf(
                    "device" to "Transcribe on phone (offline, private)",
                    "gemini" to "Transcribe + summarize with Gemini (online)",
                    "off" to "Do nothing, I'll tap when I need it",
                ).forEach { (value, label) ->
                    Row(
                        Modifier.fillMaxWidth().selectable(selected = autoMode == value, onClick = {
                            autoMode = value
                            Prefs.setAutoMode(ctx, value)
                        }),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = autoMode == value, onClick = null)
                        Spacer(Modifier.width(8.dp))
                        Text(label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                if (autoMode == "device" && modelReady[modelId] != true) {
                    Text(
                        "Download the selected model above, otherwise calls won't be transcribed automatically.",
                        color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            SectionCard("Gemini (summaries, online)") {
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = {
                        apiKey = it
                        Prefs.setApiKey(ctx, it.trim())
                    },
                    label = { Text("Gemini API key") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = "Show key")
                        }
                    }
                )
                TextButton(onClick = {
                    open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
                }) { Text("Get a free key at aistudio.google.com") }
                OutlinedTextField(
                    value = model,
                    onValueChange = {
                        model = it
                        Prefs.setModel(ctx, it.trim())
                    },
                    label = { Text("Model") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Only used when you tap Summarize, or if you pick Gemini above. The audio is sent to Google for that one request.",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            SectionCard("Good to know") {
                Text(
                    "Recording your own calls is generally allowed in India, but courts have raised privacy concerns when the other person doesn't know. When it matters, tell them the call is recorded.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun StepRow(title: String, desc: String, ok: Boolean, onFix: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (ok) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = if (ok) "Done" else "Needs attention",
            tint = if (ok) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(desc, style = MaterialTheme.typography.bodySmall)
        }
        if (!ok) TextButton(onClick = onFix) { Text("Fix") }
    }
}

private fun open(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Couldn't open that screen on this phone", Toast.LENGTH_SHORT).show()
    }
}

// ───────────────────────── Voice recorder ─────────────────────────

@Composable
fun RecordScreen(onBack: () -> Unit, onSaved: (String) -> Unit) {
    val ctx = LocalContext.current
    val st by VoiceMemoService.state.collectAsState()
    val saved by VoiceMemoService.lastSaved.collectAsState()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var level by remember { mutableFloatStateOf(0f) }
    var saving by remember { mutableStateOf(false) }

    LaunchedEffect(saved) {
        saved?.let {
            VoiceMemoService.consumeSaved()
            onSaved(it)
        }
    }
    LaunchedEffect(st.recording, st.paused) {
        while (st.recording) {
            now = System.currentTimeMillis()
            val a = VoiceMemoService.amplitude() / 32767f
            level = if (st.paused) 0f else (level * 0.6f + a * 0.4f)
            delay(100)
        }
        level = 0f
    }

    fun send(action: String) {
        val i = Intent(ctx, VoiceMemoService::class.java).setAction(action)
        if (action == VoiceMemoService.ACTION_START) ContextCompat.startForegroundService(ctx, i) else ctx.startService(i)
    }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.RECORD_AUDIO] == true) send(VoiceMemoService.ACTION_START)
        else Toast.makeText(ctx, "Microphone permission is needed to record", Toast.LENGTH_LONG).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Voice recorder") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                Fmt.dur(st.elapsed(now)),
                style = MaterialTheme.typography.displayLarge,
                fontWeight = FontWeight.Light
            )
            Spacer(Modifier.height(8.dp))
            Text(
                when {
                    saving -> "Saving…"
                    !st.recording -> "Tap to start. Meetings, lectures, notes."
                    st.paused -> "Paused"
                    else -> "Recording · works with the screen off"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(32.dp))
            // Level meter: 24 bars that bounce with your voice
            Row(
                Modifier.fillMaxWidth().height(64.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(24) { i ->
                    val shape = 0.35f + 0.65f * kotlin.math.abs(kotlin.math.sin((i + now / 120.0) * 0.7)).toFloat()
                    val h = (6f + 58f * (level * 3f).coerceAtMost(1f) * shape).dp
                    Box(
                        Modifier.width(6.dp).height(h).clip(CircleShape)
                            .background(if (st.recording && !st.paused) Color(0xFFD32F2F) else MaterialTheme.colorScheme.outlineVariant)
                    )
                }
            }
            Spacer(Modifier.height(48.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(32.dp)) {
                if (st.recording) {
                    FilledTonalIconButton(
                        onClick = { send(if (st.paused) VoiceMemoService.ACTION_RESUME else VoiceMemoService.ACTION_PAUSE) },
                        modifier = Modifier.size(64.dp)
                    ) {
                        Icon(if (st.paused) Icons.Default.Mic else Icons.Default.Pause, contentDescription = if (st.paused) "Resume" else "Pause")
                    }
                }
                Box(
                    Modifier.size(88.dp).clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable(enabled = !saving) {
                            if (st.recording) {
                                saving = true
                                send(VoiceMemoService.ACTION_STOP)
                            } else {
                                val need = buildList {
                                    add(Manifest.permission.RECORD_AUDIO)
                                    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
                                }.toTypedArray()
                                perms.launch(need)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier
                            .size(if (st.recording) 34.dp else 66.dp)
                            .clip(if (st.recording) MaterialTheme.shapes.small else CircleShape)
                            .background(Color(0xFFD32F2F))
                    )
                }
            }
            Spacer(Modifier.height(32.dp))
            Text(
                "The transcript appears right after you stop, made on your phone.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

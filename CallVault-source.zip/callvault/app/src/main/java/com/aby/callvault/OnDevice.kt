package com.aby.callvault

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteOrder

/** JNI bridge to whisper.cpp (see src/main/cpp). */
object WhisperLib {
    init {
        System.loadLibrary("callvault_whisper")
    }

    external fun initContext(modelPath: String): Long
    external fun freeContext(ctx: Long)
    external fun fullTranscribe(ctx: Long, threads: Int, language: String, audio: FloatArray, nSamples: Int): Int
    external fun segmentCount(ctx: Long): Int
    external fun segmentText(ctx: Long, i: Int): ByteArray
    external fun segmentT0(ctx: Long, i: Int): Long
    external fun segmentT1(ctx: Long, i: Int): Long
    external fun progress(): Int
    external fun abort()
}

/** Speech models that run fully on the phone. Downloaded once, then work offline. */
object Models {
    data class Model(val id: String, val label: String, val file: String, val sizeMb: Int, val note: String)

    val all = listOf(
        Model("base.en", "Standard", "ggml-base.en-q5_1.bin", 60, "Recommended. Good accuracy, ~2 min per 10 min call"),
        Model("small.en", "High accuracy", "ggml-small.en-q5_1.bin", 190, "Better with accents and noise, about 3x slower"),
        Model("tiny.en", "Fast", "ggml-tiny.en-q5_1.bin", 32, "Quickest, makes more mistakes"),
    )

    fun selected(c: Context): Model = all.firstOrNull { it.id == Prefs.modelId(c) } ?: all.first()
    fun file(c: Context, m: Model) = File(File(c.filesDir, "models").apply { mkdirs() }, m.file)
    fun isReady(c: Context, m: Model = selected(c)) = file(c, m).let { it.exists() && it.length() > 1_000_000 }
    private fun url(m: Model) = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/${m.file}"

    /** Download progress 0..100 for the model id being downloaded, or null. */
    private val _downloading = MutableStateFlow<Pair<String, Int>?>(null)
    val downloading: StateFlow<Pair<String, Int>?> = _downloading

    suspend fun download(c: Context, m: Model) = withContext(Dispatchers.IO) {
        val target = file(c, m)
        val part = File(target.parentFile, target.name + ".part")
        _downloading.value = m.id to 0
        try {
            var url = URL(url(m))
            var conn: HttpURLConnection
            var hops = 0
            while (true) { // follow redirects (Hugging Face uses a CDN)
                conn = (url.openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 30_000
                    readTimeout = 60_000
                }
                val code = conn.responseCode
                if (code in 300..399 && hops++ < 5) {
                    url = URL(url, conn.getHeaderField("Location"))
                    conn.disconnect()
                    continue
                }
                if (code !in 200..299) throw IOException("Download failed (HTTP $code)")
                break
            }
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: (m.sizeMb * 1_000_000L)
            conn.inputStream.use { input ->
                part.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        _downloading.value = m.id to ((done * 100) / total).toInt().coerceIn(0, 100)
                    }
                }
            }
            if (!part.renameTo(target)) throw IOException("Could not save the model")
        } finally {
            part.delete()
            _downloading.value = null
        }
    }

    fun delete(c: Context, m: Model) {
        file(c, m).delete()
    }
}

/**
 * Turns any audio file (m4a, mp3, wav, ogg…) into 16 kHz mono floats, which Whisper needs.
 * Streams the audio and hands it over in chunks, so long calls don't use too much memory.
 */
object AudioDecoder {
    const val RATE = 16_000

    fun decode(c: Context, uri: Uri, chunkSeconds: Int, onChunk: (FloatArray, Int, Long) -> Unit) {
        val ex = MediaExtractor()
        ex.setDataSource(c, uri, null)
        var track = -1
        for (i in 0 until ex.trackCount) {
            if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                track = i
                break
            }
        }
        if (track < 0) {
            ex.release()
            throw IOException("No audio found in this file")
        }
        ex.selectTrack(track)
        val fmt = ex.getTrackFormat(track)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0)
        codec.start()

        var inRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var isFloat = false

        val chunk = FloatArray(RATE * chunkSeconds)
        var filled = 0
        var chunkStartSample = 0L
        // linear resampler state
        var ratio = inRate.toDouble() / RATE
        var inIndex = 0L
        var nextOut = 0.0
        var prev = 0f

        fun emit(v: Float) {
            chunk[filled++] = v
            if (filled == chunk.size) {
                onChunk(chunk, filled, chunkStartSample * 1000 / RATE)
                chunkStartSample += filled
                filled = 0
            }
        }

        fun push(sample: Float) {
            while (nextOut <= inIndex) {
                val frac = (nextOut - (inIndex - 1)).toFloat().coerceIn(0f, 1f)
                emit(prev + (sample - prev) * frac)
                nextOut += ratio
            }
            prev = sample
            inIndex++
        }

        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        try {
            while (!outDone) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi >= 0) {
                    val ob = codec.getOutputBuffer(oi)!!
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    ob.order(ByteOrder.nativeOrder())
                    if (isFloat) {
                        val fb = ob.asFloatBuffer()
                        val frames = fb.remaining() / channels
                        for (f in 0 until frames) {
                            var sum = 0f
                            for (ch in 0 until channels) sum += fb.get()
                            push(sum / channels)
                        }
                    } else {
                        val sb = ob.asShortBuffer()
                        val frames = sb.remaining() / channels
                        for (f in 0 until frames) {
                            var sum = 0f
                            for (ch in 0 until channels) sum += sb.get() / 32768f
                            push(sum / channels)
                        }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    inRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                    isFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    ratio = inRate.toDouble() / RATE
                }
            }
            if (filled > RATE / 2) onChunk(chunk, filled, chunkStartSample * 1000 / RATE)
        } finally {
            runCatching { codec.stop() }
            runCatching { codec.release() }
            ex.release()
        }
    }
}

/** Transcribes a recording fully on the phone. Returns timed segments. */
object OnDeviceEngine {
    private val lock = Any()

    fun transcribe(c: Context, r: Recording, onProgress: (Int) -> Unit): List<Segment> = synchronized(lock) {
        val model = Models.selected(c)
        val path = Models.file(c, model)
        if (!Models.isReady(c, model)) throw IOException("Download the on-phone speech model in Settings first")

        val ctx = WhisperLib.initContext(path.absolutePath)
        if (ctx == 0L) throw IOException("Could not load the speech model. Try downloading it again.")
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
        val total = r.durationMs.coerceAtLeast(1)
        val out = mutableListOf<Segment>()
        try {
            AudioDecoder.decode(c, Uri.parse(r.fileUri), chunkSeconds = 300) { audio, n, offsetMs ->
                val pct = { WhisperLib.progress() }
                val watcher = Thread {
                    try {
                        while (!Thread.currentThread().isInterrupted) {
                            val doneMs = offsetMs + (n / 16L) * pct() / 100 // n samples at 16 kHz = n/16 ms
                            onProgress((doneMs * 100 / total).toInt().coerceIn(0, 99))
                            Thread.sleep(500)
                        }
                    } catch (_: InterruptedException) {
                    }
                }
                watcher.start()
                val rc = try {
                    WhisperLib.fullTranscribe(ctx, threads, "en", audio, n)
                } finally {
                    watcher.interrupt()
                }
                if (rc != 0) throw IOException("On-phone transcription failed (code $rc)")
                for (i in 0 until WhisperLib.segmentCount(ctx)) {
                    val text = String(WhisperLib.segmentText(ctx, i), Charsets.UTF_8).trim()
                    if (text.isEmpty() || text.matches(Regex("^[\\[(].*[\\])]$"))) continue // skip [BLANK_AUDIO], (music)
                    out += Segment(
                        startMs = offsetMs + WhisperLib.segmentT0(ctx, i) * 10,
                        endMs = offsetMs + WhisperLib.segmentT1(ctx, i) * 10,
                        text = text
                    )
                }
                onProgress(((offsetMs + n * 1000L / AudioDecoder.RATE) * 100 / total).toInt().coerceIn(0, 99))
            }
        } catch (e: Exception) {
            Log.e("CallVault", "On-device transcription failed", e)
            throw e
        } finally {
            WhisperLib.freeContext(ctx)
        }
        out
    }
}

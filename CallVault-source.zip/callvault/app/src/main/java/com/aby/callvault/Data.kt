package com.aby.callvault

import android.Manifest
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_REC, "Call recording in progress", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_INFO, "Saved recordings", NotificationManager.IMPORTANCE_DEFAULT)
        )
        Library.init(this)
    }

    companion object {
        const val CH_REC = "recording"
        const val CH_INFO = "saved"
    }
}

data class Recording(
    val id: String,
    val fileUri: String,
    val fileName: String,
    val timestamp: Long,
    val durationMs: Long,
    val number: String = "",
    val contactName: String = "",
    val direction: String = "unknown", // in, out, missed, unknown
    val source: String = "app",        // app, import
    val tags: List<String> = emptyList(),
    val notes: String = "",
    val transcript: String = "",
    val summary: String = "",
    val actionItems: List<String> = emptyList(),
    val language: String = "",
    val aiState: String = "",          // Gemini: "", running, done, error
    val aiError: String = "",
    val segments: List<Segment> = emptyList(), // on-phone transcript with timings
    val deviceState: String = "",      // on-phone: "", running, done, error
    val deviceError: String = "",
) {
    val segmentText: String get() = segments.joinToString(" ") { it.text }

    val displayName: String get() = contactName.ifBlank { number.ifBlank { fileName } }
    val personKey: String get() =
        if (direction == "memo") "Voice memos" else contactName.ifBlank { number.ifBlank { "Unknown" } }

    fun matches(q: String): Boolean {
        if (q.isBlank()) return true
        val needle = q.trim()
        return listOf(contactName, number, fileName, notes, transcript, summary, segmentText, tags.joinToString(" "))
            .any { it.contains(needle, ignoreCase = true) } ||
            actionItems.any { it.contains(needle, ignoreCase = true) }
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("fileUri", fileUri); put("fileName", fileName)
        put("timestamp", timestamp); put("durationMs", durationMs)
        put("number", number); put("contactName", contactName)
        put("direction", direction); put("source", source)
        put("tags", JSONArray(tags)); put("notes", notes)
        put("transcript", transcript); put("summary", summary)
        put("actionItems", JSONArray(actionItems)); put("language", language)
        put("aiState", aiState); put("aiError", aiError)
        put("segments", JSONArray().apply { segments.forEach { put(it.toJson()) } })
        put("deviceState", deviceState); put("deviceError", deviceError)
    }

    companion object {
        fun fromJson(o: JSONObject) = Recording(
            id = o.getString("id"),
            fileUri = o.getString("fileUri"),
            fileName = o.optString("fileName"),
            timestamp = o.optLong("timestamp"),
            durationMs = o.optLong("durationMs"),
            number = o.optString("number"),
            contactName = o.optString("contactName"),
            direction = o.optString("direction", "unknown"),
            source = o.optString("source", "app"),
            tags = o.optJSONArray("tags").toStringList(),
            notes = o.optString("notes"),
            transcript = o.optString("transcript"),
            summary = o.optString("summary"),
            actionItems = o.optJSONArray("actionItems").toStringList(),
            language = o.optString("language"),
            // a transcription that was running when the app closed is treated as not started
            aiState = o.optString("aiState").let { if (it == "running") "" else it },
            aiError = o.optString("aiError"),
            segments = o.optJSONArray("segments")?.let { a ->
                (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { Segment.fromJson(it) } }
            } ?: emptyList(),
            deviceState = o.optString("deviceState").let { if (it == "running") "" else it },
            deviceError = o.optString("deviceError"),
        )
    }
}

data class Segment(val startMs: Long, val endMs: Long, val text: String) {
    fun toJson(): JSONObject = JSONObject().put("s", startMs).put("e", endMs).put("t", text)

    companion object {
        fun fromJson(o: JSONObject) = Segment(o.optLong("s"), o.optLong("e"), o.optString("t"))
    }
}

fun JSONArray?.toStringList(): List<String> =
    if (this == null) emptyList() else (0 until length()).map { optString(it) }.filter { it.isNotBlank() }

/** Simple on-device library: one JSON file in the app's private storage. */
object Library {
    private lateinit var file: File
    private val lock = Any()
    private val _items = MutableStateFlow<List<Recording>>(emptyList())
    val items: StateFlow<List<Recording>> = _items

    fun init(c: Context) {
        file = File(c.filesDir, "library.json")
        _items.value = load()
    }

    private fun load(): List<Recording> = try {
        if (!file.exists()) emptyList() else {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { Recording.fromJson(arr.getJSONObject(it)) }
                .sortedByDescending { it.timestamp }
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun persist(list: List<Recording>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        val tmp = File(file.parentFile, "library.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(file)
    }

    fun get(id: String): Recording? = _items.value.firstOrNull { it.id == id }

    fun upsert(r: Recording) = synchronized(lock) {
        val list = (_items.value.filterNot { it.id == r.id } + r).sortedByDescending { it.timestamp }
        _items.value = list
        persist(list)
    }

    fun update(id: String, change: (Recording) -> Recording) = synchronized(lock) {
        val cur = get(id)
        if (cur != null) upsert(change(cur))
        Unit
    }

    fun delete(c: Context, id: String) = synchronized(lock) {
        val r = get(id) ?: return@synchronized
        Storage.delete(c, r.fileUri)
        val list = _items.value.filterNot { it.id == id }
        _items.value = list
        persist(list)
    }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun autoRecord(c: Context) = sp(c).getBoolean("auto", true)
    fun setAutoRecord(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto", v).apply()

    /** What happens right after a call is saved or a file is uploaded: device, gemini, off */
    fun autoMode(c: Context) = sp(c).getString("auto_mode", "device") ?: "device"
    fun setAutoMode(c: Context, v: String) = sp(c).edit().putString("auto_mode", v).apply()

    fun modelId(c: Context) = sp(c).getString("model_id", "base.en") ?: "base.en"
    fun setModelId(c: Context, v: String) = sp(c).edit().putString("model_id", v).apply()

    fun audioSource(c: Context) = sp(c).getInt("source", MediaRecorder.AudioSource.VOICE_RECOGNITION)
    fun setAudioSource(c: Context, v: Int) = sp(c).edit().putInt("source", v).apply()

    fun folderUri(c: Context): String? = sp(c).getString("folder", null)
    fun setFolder(c: Context, v: String?) = sp(c).edit().putString("folder", v).apply()

    fun apiKey(c: Context) = sp(c).getString("key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("key", v).apply()

    const val DEFAULT_MODEL = "gemini-2.5-flash"
    fun model(c: Context) = (sp(c).getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL).ifBlank { DEFAULT_MODEL }
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v).apply()
}

object Setup {
    fun permissions(): Array<String> = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.READ_CALL_LOG)
        add(Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    fun permissionsGranted(c: Context) = permissions().all {
        ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED
    }

    fun accessibilityEnabled(c: Context): Boolean {
        val enabled = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(c, CallRecordService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    fun batteryUnrestricted(c: Context): Boolean =
        c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)

    fun isReady(c: Context) = permissionsGranted(c) && accessibilityEnabled(c)
}

object Fmt {
    fun date(ms: Long): String = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(Date(ms))
    fun fileStamp(ms: Long): String = SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date(ms))
    fun dur(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
        else "%d:%02d".format(s / 60, s % 60)
    }
    fun direction(d: String) = when (d) {
        "in" -> "↙ Incoming"
        "out" -> "↗ Outgoing"
        "missed" -> "Missed"
        "memo" -> "🎙 Voice memo"
        else -> "Call"
    }
}

package com.aby.callvault

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.IntentCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)
    private val pendingOpen = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            CallVaultTheme {
                AppRoot(resumeTick.intValue, pendingOpen)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        i.getStringExtra(EXTRA_OPEN)?.let { pendingOpen.value = it }
        if (i.getBooleanExtra(EXTRA_RECORDER, false)) pendingOpen.value = OPEN_RECORDER
        val uris = mutableListOf<Uri>()
        when (i.action) {
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { uris += it }
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { uris += it }
        }
        if (uris.isNotEmpty()) importUris(uris)
    }

    private fun importUris(uris: List<Uri>) {
        lifecycleScope.launch {
            val n = withContext(Dispatchers.IO) {
                uris.count { runCatching { Importer.import(this@MainActivity, it) }.getOrNull() != null }
            }
            Toast.makeText(this@MainActivity, "Imported $n recording(s)", Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        const val EXTRA_OPEN = "open_id"
        const val EXTRA_RECORDER = "open_recorder"
        const val OPEN_RECORDER = "__recorder__"
    }
}

sealed interface Screen {
    data object Home : Screen
    data class Detail(val id: String) : Screen
    data object Settings : Screen
    data object Record : Screen
}

@Composable
fun AppRoot(tick: Int, pendingOpen: MutableState<String?>) {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    LaunchedEffect(pendingOpen.value) {
        pendingOpen.value?.let {
            screen = if (it == MainActivity.OPEN_RECORDER) Screen.Record else Screen.Detail(it)
            pendingOpen.value = null
        }
    }
    BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }
    when (val s = screen) {
        Screen.Home -> HomeScreen(
            tick = tick,
            onOpen = { screen = Screen.Detail(it) },
            onSettings = { screen = Screen.Settings },
            onRecord = { screen = Screen.Record },
        )
        is Screen.Detail -> DetailScreen(id = s.id, onBack = { screen = Screen.Home })
        Screen.Settings -> SettingsScreen(tick = tick, onBack = { screen = Screen.Home })
        Screen.Record -> RecordScreen(onBack = { screen = Screen.Home }, onSaved = { screen = Screen.Detail(it) })
    }
}

@Composable
fun CallVaultTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(primary = Color(0xFF6FD3A8))
        else -> lightColorScheme(primary = Color(0xFF0B6E4F))
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
